

<?php $__env->startSection('title', 'Lab Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <a href="<?php echo e(route('labs.index')); ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Back to Labs
    </a>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body">
                <h4 class="mb-3">
                    <i class="bi bi-building text-primary"></i> <?php echo e($lab->name); ?>

                </h4>
                
                <div class="mb-3">
                    <h6 class="text-muted mb-2"><i class="bi bi-geo-alt"></i> Location</h6>
                    <p class="mb-0"><?php echo e($lab->location); ?></p>
                </div>
                
                <div class="mb-3">
                    <h6 class="text-muted mb-2"><i class="bi bi-people"></i> Capacity</h6>
                    <p class="mb-0"><?php echo e($lab->capacity); ?> people</p>
                </div>
                
                <hr>
                
                <div class="row text-center">
                    <div class="col-6">
                        <h4 class="text-primary mb-0"><?php echo e($lab->assets_count); ?></h4>
                        <small class="text-muted">Assets</small>
                    </div>
                    <div class="col-6">
                        <h4 class="text-success mb-0"><?php echo e($lab->bookings_count); ?></h4>
                        <small class="text-muted">Bookings</small>
                    </div>
                </div>
                
                <?php if(auth()->user()->isSuperadmin() || auth()->user()->isStaff()): ?>
                <hr>
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('labs.edit', $lab)); ?>" class="btn btn-primary">
                        <i class="bi bi-pencil"></i> Edit Lab
                    </a>
                    <form action="<?php echo e(route('labs.destroy', $lab)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger w-100" 
                                onclick="return confirm('Are you sure you want to delete this lab?')">
                            <i class="bi bi-trash"></i> Delete Lab
                        </button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">
                    <i class="bi bi-laptop"></i> Assets in This Lab
                </h5>
            </div>
            <div class="card-body">
                <?php if($lab->assets->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Code</th>
                                    <th>Name</th>
                                    <th>Condition</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $lab->assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><code><?php echo e($asset->code); ?></code></td>
                                    <td><?php echo e($asset->name); ?></td>
                                    <td>
                                        <span class="badge <?php echo e($asset->condition === 'good' ? 'bg-success' : 'bg-danger'); ?>">
                                            <?php echo e(ucfirst($asset->condition)); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('assets.show', $asset)); ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5 text-muted">
                        <i class="bi bi-inbox" style="font-size: 2rem;"></i>
                        <p class="mt-2">No assets in this lab yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\x1\Desktop\New folder\webuas\resources\views/labs/show.blade.php ENDPATH**/ ?>