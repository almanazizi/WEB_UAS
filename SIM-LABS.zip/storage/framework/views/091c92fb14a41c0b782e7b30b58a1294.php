<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #000000;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .header {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="header">
        Laporan Data Pengunjung Laboratorium<br>
        Tanggal Unduh: <?php echo e(date('d F Y')); ?>

    </div>

    <table>
        <thead>
            <tr>
                <th style="width: 50px;">No</th>
                <th style="width: 120px;">Tanggal</th>
                <th style="width: 80px;">Jam</th>
                <th style="width: 100px;">NIM</th>
                <th style="width: 200px;">Nama</th>
                <th style="width: 200px;">Laboratorium</th>
                <th style="width: 300px;">Keperluan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $guests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($guest->check_in_time->format('d/m/Y')); ?></td>
                <td><?php echo e($guest->check_in_time->format('H:i')); ?></td>
                <td style="mso-number-format:'\@'"><?php echo e($guest->nim); ?></td>
                <td><?php echo e($guest->nama); ?></td>
                <td><?php echo e($guest->lab->name); ?></td>
                <td><?php echo e($guest->purpose); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\x1\Desktop\New folder\webuas - fix\resources\views/staff/guests/export_excel.blade.php ENDPATH**/ ?>