
<div class="card border-0 shadow-sm">
    <div class="card-body">
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-0 fw-bold">
                    <?php echo e(\Carbon\Carbon::parse($date)->format('F Y')); ?>

                </h4>
            </div>
            <div class="btn-group">
                <a href="<?php echo e(route('schedule.index', ['view' => 'monthly', 'date' => \Carbon\Carbon::parse($date)->subMonth()->format('Y-m-d'), 'lab_id' => $labId])); ?>" 
                   class="btn btn-outline-secondary btn-sm">
                    <i class="bi bi-chevron-left"></i>
                </a>
                <a href="<?php echo e(route('schedule.index', ['view' => 'monthly', 'date' => now()->format('Y-m-d'), 'lab_id' => $labId])); ?>" 
                   class="btn btn-outline-secondary btn-sm">
                    Today
                </a>
                <a href="<?php echo e(route('schedule.index', ['view' => 'monthly', 'date' => \Carbon\Carbon::parse($date)->addMonth()->format('Y-m-d'), 'lab_id' => $labId])); ?>" 
                   class="btn btn-outline-secondary btn-sm">
                    <i class="bi bi-chevron-right"></i>
                </a>
            </div>
        </div>

        
        <div class="table-responsive">
            <table class="table table-bordered monthly-calendar">
                <thead>
                    <tr class="text-center">
                        <th class="text-muted small fw-normal">Sun</th>
                        <th class="text-muted small fw-normal">Mon</th>
                        <th class="text-muted small fw-normal">Tue</th>
                        <th class="text-muted small fw-normal">Wed</th>
                        <th class="text-muted small fw-normal">Thu</th>
                        <th class="text-muted small fw-normal">Fri</th>
                        <th class="text-muted small fw-normal">Sat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $currentDate = \Carbon\Carbon::parse($date)->startOfMonth();
                        $endDate = \Carbon\Carbon::parse($date)->endOfMonth();
                        $startDay = $currentDate->copy()->startOfWeek(\Carbon\Carbon::SUNDAY);
                        $endDay = $endDate->copy()->endOfWeek(\Carbon\Carbon::SUNDAY);
                        
                        // Group bookings by date
                        $bookingsByDate = $bookings->groupBy(function($booking) {
                            return $booking->start_time->format('Y-m-d');
                        });
                    ?>

                    <?php while($startDay <= $endDay): ?>
                        <tr>
                            <?php for($i = 0; $i < 7; $i++): ?>
                                <?php
                                    $day = $startDay->copy()->addDays($i);
                                    $dateKey = $day->format('Y-m-d');
                                    $isCurrentMonth = $day->month == $currentDate->month;
                                    $isToday = $day->isToday();
                                    $dayBookings = $bookingsByDate->get($dateKey, collect());
                                ?>
                                <td class="calendar-cell <?php echo e(!$isCurrentMonth ? 'other-month' : ''); ?> <?php echo e($isToday ? 'today' : ''); ?>" 
                                    style="min-height: 100px; vertical-align: top; padding: 8px;">
                                    <div class="date-number <?php echo e($isToday ? 'fw-bold text-primary' : ''); ?> mb-2">
                                        <?php echo e($day->format('d')); ?>

                                    </div>
                                    
                                    <?php if($dayBookings->count() > 0): ?>
                                        <?php $__currentLoopData = $dayBookings->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="event-block mb-1 p-1 rounded small" 
                                                 style="background: <?php echo e($booking->status === 'approved' ? '#e3f2fd' : '#fff3cd'); ?>; 
                                                        border-left: 3px solid <?php echo e($booking->status === 'approved' ? '#2196f3' : '#ffc107'); ?>;"
                                                 title="<?php echo e($booking->lab->name); ?> - <?php echo e($booking->user->name); ?>">
                                                <div class="text-truncate" style="font-size: 0.75rem;">
                                                    <strong><?php echo e($booking->start_time->format('H:i')); ?></strong> 
                                                    <?php echo e($booking->lab->name); ?>

                                                </div>
                                                <div class="text-truncate text-muted" style="font-size: 0.7rem;">
                                                    <?php echo e(Str::limit($booking->purpose, 20)); ?>

                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <?php if($dayBookings->count() > 3): ?>
                                            <div class="small text-muted" style="font-size: 0.7rem;">
                                                +<?php echo e($dayBookings->count() - 3); ?> more
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            <?php endfor; ?>
                        </tr>
                        <?php $startDay->addWeek(); ?>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="card border-0 shadow-sm mt-4">
    <div class="card-header bg-white">
        <h5 class="mb-0"><i class="bi bi-list-ul"></i> Jadwal Harian</h5>
    </div>
    <div class="card-body">
        <div class="row mb-3">
            <div class="col-md-6">
                <label class="form-label small">Show 
                    <select class="form-select form-select-sm d-inline-block" style="width: auto;" id="entriesCount">
                        <option value="10">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                    entries
                </label>
            </div>
            <div class="col-md-6 text-end">
                <label class="form-label small">Search:
                    <input type="text" class="form-control form-control-sm d-inline-block" style="width: 200px;" id="searchInput" placeholder="Cari...">
                </label>
            </div>
        </div>

        <?php if($bookings->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle" id="dailyScheduleTable">
                    <thead class="table-light">
                        <tr>
                            <th>Tanggal <i class="bi bi-arrow-down-up small"></i></th>
                            <th>Jam</th>
                            <th>Lab</th>
                            <th>Keterangan</th>
                            <th>Pengajuan Oleh</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bookings->sortBy('start_time'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($booking->start_time->format('d M Y')); ?></td>
                            <td>
                                <div><?php echo e($booking->start_time->format('H:i')); ?> - <?php echo e($booking->end_time->format('H:i')); ?></div>
                                <small class="text-muted"><?php echo e($booking->start_time->diffInHours($booking->end_time)); ?> jam</small>
                            </td>
                            <td>
                                <i class="bi bi-building text-primary"></i> <?php echo e($booking->lab->name); ?>

                                <br><small class="text-muted"><?php echo e($booking->lab->location); ?></small>
                            </td>
                            <td><?php echo e(Str::limit($booking->purpose, 50)); ?></td>
                            <td>
                                <div><?php echo e($booking->user->name); ?></div>
                                <small class="text-muted"><?php echo e($booking->user->email); ?></small>
                            </td>
                            <td>
                                <span class="badge 
                                    <?php if($booking->status === 'approved'): ?> bg-success
                                    <?php elseif($booking->status === 'pending'): ?> bg-warning
                                    <?php else: ?> bg-danger
                                    <?php endif; ?>">
                                    <?php echo e(ucfirst($booking->status)); ?>

                                </span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-5 text-muted">
                <i class="bi bi-calendar-x" style="font-size: 3rem;"></i>
                <p class="mt-3">Tidak ada jadwal untuk bulan ini</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.monthly-calendar {
    margin-bottom: 0;
}
.monthly-calendar td {
    width: 14.28%;
    min-height: 120px;
}
.calendar-cell {
    position: relative;
}
.calendar-cell.other-month {
    background-color: #f8f9fa;
    color: #adb5bd;
}
.calendar-cell.today {
    background-color: #fff3cd;
}
.date-number {
    font-size: 0.875rem;
}
.event-block {
    cursor: pointer;
    transition: all 0.2s;
}
.event-block:hover {
    transform: translateX(2px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}
</style>

<script>
// Simple table search and pagination
document.getElementById('searchInput')?.addEventListener('keyup', function() {
    const value = this.value.toLowerCase();
    const rows = document.querySelectorAll('#dailyScheduleTable tbody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(value) ? '' : 'none';
    });
});
</script>
<?php /**PATH C:\Users\x1\Desktop\New folder\webuas - fix  V 2\resources\views/schedule/partials/monthly_view.blade.php ENDPATH**/ ?>