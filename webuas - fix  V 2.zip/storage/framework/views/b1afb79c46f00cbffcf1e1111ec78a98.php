

<?php $__env->startSection('title', 'Detail Laboratorium'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <a href="<?php echo e(route('labs.index')); ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Kembali ke Daftar Laboratorium
    </a>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body">
                <h4 class="mb-3">
                    <i class="bi bi-building text-primary"></i> <?php echo e($lab->name); ?>

                </h4>
                
                <div class="mb-3">
                    <h6 class="text-muted mb-2"><i class="bi bi-geo-alt"></i> Lokasi</h6>
                    <p class="mb-0"><?php echo e($lab->location); ?></p>
                </div>
                
                <div class="mb-3">
                    <h6 class="text-muted mb-2"><i class="bi bi-people"></i> Kapasitas</h6>
                    <p class="mb-0"><?php echo e($lab->capacity); ?> orang</p>
                </div>
                
                <hr>
                
                <div class="row text-center mb-3">
                    <div class="col-6">
                        <div class="text-muted small">Total Aset</div>
                        <h4 class="mb-0"><?php echo e($lab->assets->count()); ?></h4>
                    </div>
                    <div class="col-6">
                        <div class="text-muted small">Peminjaman</div>
                        <h4 class="mb-0"><?php echo e($lab->bookings->count()); ?></h4>
                    </div>
                </div>
                
                <hr>
                
                <div class="small text-muted">
                    <div class="mb-1">
                        <strong>Dibuat:</strong> <?php echo e($lab->created_at->format('d M Y, H:i')); ?>

                    </div>
                    <div>
                        <strong>Diperbarui:</strong> <?php echo e($lab->updated_at->format('d M Y, H:i')); ?>

                    </div>
                </div>
                
                <?php if(auth()->user()->isStaff() || auth()->user()->isSuperadmin()): ?>
                <hr>
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('labs.edit', $lab)); ?>" class="btn btn-primary">
                        <i class="bi bi-pencil"></i> Ubah Data
                    </a>
                    <form action="<?php echo e(route('labs.destroy', $lab)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger w-100" 
                                onclick="return confirm('Yakin ingin menghapus laboratorium ini?')">
                            <i class="bi bi-trash"></i> Hapus Laboratorium
                        </button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">
                    <i class="bi bi-laptop"></i> Daftar Aset di Laboratorium
                </h5>
            </div>
            <div class="card-body">
                <?php if($lab->assets->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Kode</th>
                                    <th>Nama Aset</th>
                                    <th>Spesifikasi</th>
                                    <th>Kondisi</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $lab->assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><code><?php echo e($asset->code); ?></code></td>
                                    <td><?php echo e($asset->name); ?></td>
                                    <td><small><?php echo e(Str::limit($asset->spec, 40)); ?></small></td>
                                    <td>
                                        <span class="badge <?php echo e($asset->condition === 'good' ? 'bg-success' : 'bg-danger'); ?>">
                                            <?php echo e($asset->condition === 'good' ? 'Baik' : 'Rusak'); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('assets.show', $asset)); ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5 text-muted">
                        <i class="bi bi-inbox" style="font-size: 2rem;"></i>
                        <p class="mt-2">Belum ada aset di laboratorium ini</p>
                        <?php if(auth()->user()->isStaff()): ?>
                        <a href="<?php echo e(route('assets.create')); ?>" class="btn btn-sm btn-primary">
                            <i class="bi bi-plus-circle"></i> Tambah Aset
                        </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\x1\Desktop\New folder\webuas - fix  V 2\resources\views/labs/show.blade.php ENDPATH**/ ?>