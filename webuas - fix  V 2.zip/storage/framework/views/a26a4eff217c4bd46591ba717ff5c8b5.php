<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'SIM-LAB'); ?> - Laboratory Management System</title>
    
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 0.75rem 1rem;
            margin: 0.25rem 0;
            border-radius: 0.5rem;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
        }
        .stat-card {
            border-left: 4px solid;
            transition: transform 0.2s;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body class="bg-light">
    <?php if(auth()->guard()->check()): ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="p-3">
                    <h4 class="text-white mb-4">
                        <i class="bi bi-flask"></i> SIM-LAB
                    </h4>
                    <div class="text-white-50 small mb-3">
                        <i class="bi bi-person-circle"></i> <?php echo e(auth()->user()->name); ?>

                        <br>
                        <span class="badge bg-light text-dark mt-1">
                            <?php if(auth()->user()->isSuperadmin()): ?>
                                Superadmin
                            <?php elseif(auth()->user()->isStaff()): ?>
                                Staff/PJ Lab
                            <?php else: ?>
                                Dosen/Mahasiswa
                            <?php endif; ?>
                        </span>
                    </div>
                    <hr class="text-white-50">
                    
                    <ul class="nav flex-column">
                        <?php if(auth()->user()->isSuperadmin()): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('superadmin.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('superadmin.dashboard')); ?>">
                                    <i class="bi bi-speedometer2"></i> Beranda
                                </a>
                            </li>
                        <?php elseif(auth()->user()->isStaff()): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('staff.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('staff.dashboard')); ?>">
                                    <i class="bi bi-speedometer2"></i> Beranda
                                </a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('user.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('user.dashboard')); ?>">
                                    <i class="bi bi-speedometer2"></i> Beranda
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('labs.*') ? 'active' : ''); ?>" href="<?php echo e(route('labs.index')); ?>">
                                <i class="bi bi-building"></i> Laboratorium
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('assets.*') ? 'active' : ''); ?>" href="<?php echo e(route('assets.index')); ?>">
                                <i class="bi bi-laptop"></i> Inventaris
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('bookings.*') ? 'active' : ''); ?>" href="<?php echo e(route('bookings.index')); ?>">
                                <i class="bi bi-calendar-check"></i> Peminjaman
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('tickets.*') ? 'active' : ''); ?>" href="<?php echo e(route('tickets.index')); ?>">
                                <i class="bi bi-tools"></i> Laporan Masalah
                            </a>
                        </li>
                    </ul>
                    
                    <hr class="text-white-50">
                    
                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-light btn-sm w-100">
                            <i class="bi bi-box-arrow-right"></i> Keluar
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-4 py-4">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle"></i> <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-triangle"></i> <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <?php else: ?>
        <?php echo $__env->yieldContent('content'); ?>
    <?php endif; ?>
    
    <!-- Bootstrap 5.3 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\x1\Desktop\New folder\webuas\resources\views/layouts/app.blade.php ENDPATH**/ ?>