

<?php $__env->startSection('title', 'Booking Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <a href="<?php echo e(route('bookings.index')); ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Back to Bookings
    </a>
</div>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="bi bi-calendar-check"></i> Booking #<?php echo e($booking->id); ?>

                    </h5>
                    <span class="badge 
                        <?php if($booking->status === 'approved'): ?> bg-success
                        <?php elseif($booking->status === 'pending'): ?> bg-warning
                        <?php else: ?> bg-danger
                        <?php endif; ?>" style="font-size: 1rem;">
                        <?php echo e(ucfirst($booking->status)); ?>

                    </span>
                </div>
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h6 class="text-muted mb-2">
                            <i class="bi bi-person-circle"></i> Booked By
                        </h6>
                        <p class="mb-0"><?php echo e($booking->user->name); ?></p>
                        <small class="text-muted"><?php echo e($booking->user->email); ?></small>
                    </div>
                    
                    <div class="col-md-6">
                        <h6 class="text-muted mb-2">
                            <i class="bi bi-building"></i> Laboratory
                        </h6>
                        <p class="mb-0"><?php echo e($booking->lab->name); ?></p>
                        <small class="text-muted"><?php echo e($booking->lab->location); ?></small>
                    </div>
                </div>
                
                <hr>
                
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h6 class="text-muted mb-2">
                            <i class="bi bi-clock"></i> Start Time
                        </h6>
                        <p class="mb-0 fw-semibold"><?php echo e($booking->start_time->format('d F Y')); ?></p>
                        <p class="mb-0"><?php echo e($booking->start_time->format('H:i')); ?> WIB</p>
                    </div>
                    
                    <div class="col-md-6">
                        <h6 class="text-muted mb-2">
                            <i class="bi bi-clock-fill"></i> End Time
                        </h6>
                        <p class="mb-0 fw-semibold"><?php echo e($booking->end_time->format('d F Y')); ?></p>
                        <p class="mb-0"><?php echo e($booking->end_time->format('H:i')); ?> WIB</p>
                    </div>
                </div>
                
                <hr>
                
                <div class="mb-4">
                    <h6 class="text-muted mb-2">
                        <i class="bi bi-file-text"></i> Purpose
                    </h6>
                    <p class="mb-0"><?php echo e($booking->purpose); ?></p>
                </div>
                
                <hr>
                
                <div class="row">
                    <div class="col-md-6">
                        <small class="text-muted">Created at:</small>
                        <p class="mb-0"><?php echo e($booking->created_at->format('d M Y, H:i')); ?></p>
                    </div>
                    <div class="col-md-6">
                        <small class="text-muted">Last updated:</small>
                        <p class="mb-0"><?php echo e($booking->updated_at->format('d M Y, H:i')); ?></p>
                    </div>
                </div>
                
                <?php if(auth()->user()->isStaff() && $booking->status === 'pending'): ?>
                <hr>
                <div class="d-flex gap-2">
                    <form action="<?php echo e(route('bookings.updateStatus', $booking)); ?>" method="POST" class="flex-fill">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="status" value="approved">
                        <button type="submit" class="btn btn-success w-100">
                            <i class="bi bi-check-circle"></i> Approve Booking
                        </button>
                    </form>
                    <form action="<?php echo e(route('bookings.updateStatus', $booking)); ?>" method="POST" class="flex-fill">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="status" value="rejected">
                        <button type="submit" class="btn btn-danger w-100">
                            <i class="bi bi-x-circle"></i> Reject Booking
                        </button>
                    </form>
                </div>
                <?php endif; ?>
                
                <?php if($booking->user_id === auth()->id() && $booking->status === 'pending'): ?>
                <hr>
                <form action="<?php echo e(route('bookings.destroy', $booking)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger w-100" 
                            onclick="return confirm('Are you sure you want to cancel this booking?')">
                        <i class="bi bi-trash"></i> Cancel Booking
                    </button>
                </form>
                <?php endif; ?>
                
                
                <hr>
                <div class="mb-4">
                    <h5 class="mb-3">
                        <i class="bi bi-people-fill text-primary"></i> Daftar Pengunjung Lab
                    </h5>
                    
                    <?php if($booking->visitors->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="60">No</th>
                                    <th>NIM</th>
                                    <th>Nama</th>
                                    <?php if(auth()->user()->isSuperadmin() || auth()->user()->isStaff() || $booking->user_id === auth()->id()): ?>
                                    <th width="80" class="text-center">Aksi</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $booking->visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><span class="badge bg-info"><?php echo e($visitor->nim); ?></span></td>
                                    <td><?php echo e($visitor->nama); ?></td>
                                    <?php if(auth()->user()->isSuperadmin() || auth()->user()->isStaff() || $booking->user_id === auth()->id()): ?>
                                    <td class="text-center">
                                        <form action="<?php echo e(route('bookings.visitors.remove', [$booking, $visitor->id])); ?>" 
                                              method="POST" 
                                              style="display: inline;"
                                              onsubmit="return confirm('Yakin ingin menghapus pengunjung ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="alert alert-info mb-3">
                        <i class="bi bi-info-circle"></i> Belum ada pengunjung yang terdaftar untuk peminjaman ini.
                    </div>
                    <?php endif; ?>
                    
                    
                    <?php if(auth()->user()->isSuperadmin() || auth()->user()->isStaff() || $booking->user_id === auth()->id()): ?>
                    <div class="card bg-light border-0 mt-3">
                        <div class="card-body">
                            <h6 class="card-title mb-3">
                                <i class="bi bi-person-plus-fill"></i> Tambah Pengunjung
                            </h6>
                            
                            <form action="<?php echo e(route('bookings.visitors.add', $booking)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <label for="nim" class="form-label">NIM <span class="text-danger">*</span></label>
                                        <input type="text" 
                                               class="form-control <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="nim" 
                                               name="nim" 
                                               value="<?php echo e(old('nim')); ?>"
                                               placeholder="Masukkan NIM"
                                               maxlength="20"
                                               required>
                                        <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="nama" class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                        <input type="text" 
                                               class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                               id="nama" 
                                               name="nama" 
                                               value="<?php echo e(old('nama')); ?>"
                                               placeholder="Masukkan nama lengkap"
                                               maxlength="100"
                                               required>
                                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-2 d-flex align-items-end">
                                        <button type="submit" class="btn btn-primary w-100">
                                            <i class="bi bi-plus-circle"></i> Tambah
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\x1\Desktop\New folder\webuas - fix\resources\views/bookings/show.blade.php ENDPATH**/ ?>