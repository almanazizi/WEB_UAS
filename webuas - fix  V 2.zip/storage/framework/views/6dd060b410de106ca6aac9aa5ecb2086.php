

<?php $__env->startSection('title', 'Dashboard Pengunjung'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h2><i class="bi bi-people-fill"></i> Dashboard Pengunjung</h2>
    <p class="text-muted">Analitik dan manajemen pengunjung laboratorium</p>
</div>


<div class="card mb-4">
    <div class="card-body">
        <form action="<?php echo e(route('staff.visitors.dashboard')); ?>" method="GET" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Filter Periode</label>
                <select name="filter" id="filterSelect" class="form-select">
                    <option value="today" <?php echo e($filter == 'today' ? 'selected' : ''); ?>>Hari Ini</option>
                    <option value="7days" <?php echo e($filter == '7days' ? 'selected' : ''); ?>>7 Hari Terakhir</option>
                    <option value="30days" <?php echo e($filter == '30days' ? 'selected' : ''); ?>>30 Hari Terakhir</option>
                    <option value="custom" <?php echo e($filter == 'custom' ? 'selected' : ''); ?>>Custom Range</option>
                </select>
            </div>
            <div class="col-md-3" id="dateFromGroup" style="display: <?php echo e($filter == 'custom' ? 'block' : 'none'); ?>;">
                <label class="form-label">Dari Tanggal</label>
                <input type="date" name="date_from" class="form-control" value="<?php echo e($dateFrom); ?>">
            </div>
            <div class="col-md-3" id="dateToGroup" style="display: <?php echo e($filter == 'custom' ? 'block' : 'none'); ?>;">
                <label class="form-label">Sampai Tanggal</label>
                <input type="date" name="date_to" class="form-control" value="<?php echo e($dateTo); ?>">
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-funnel"></i> Terapkan Filter
                </button>
            </div>
        </form>
    </div>
</div>


<div class="row mb-4">
    <div class="col-md-3">
        <div class="card stat-card border-0 shadow-sm" style="border-left-color: #667eea !important;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0">
                        <i class="bi bi-people-fill fs-2 text-primary"></i>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <p class="text-muted small mb-1">Total (All Time)</p>
                        <h3 class="mb-0"><?php echo e(number_format($stats['total_all_time'])); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card border-0 shadow-sm" style="border-left-color: #28a745 !important;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0">
                        <i class="bi bi-calendar-check fs-2 text-success"></i>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <p class="text-muted small mb-1">Booking Visitors</p>
                        <h3 class="mb-0"><?php echo e(number_format($stats['booking_count'])); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card border-0 shadow-sm" style="border-left-color: #17a2b8 !important;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0">
                        <i class="bi bi-person-check-fill fs-2 text-info"></i>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <p class="text-muted small mb-1">Walk-in Visitors</p>
                        <h3 class="mb-0"><?php echo e(number_format($stats['walkin_count'])); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card border-0 shadow-sm" style="border-left-color: #ffc107 !important;">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0">
                        <i class="bi bi-clock-fill fs-2 text-warning"></i>
                    </div>
                    <div class="flex-grow-1 ms-3">
                        <p class="text-muted small mb-1">Aktif Sekarang</p>
                        <h3 class="mb-0"><?php echo e(number_format($stats['active_now'])); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php if($pendingCount > 0): ?>
<div class="alert alert-info border-0 shadow-sm mb-4">
    <div class="d-flex align-items-center">
        <i class="bi bi-bell-fill fs-4 me-3"></i>
        <div>
            <strong><?php echo e($pendingCount); ?> pengunjung menunggu approval</strong>
            <a href="<?php echo e(route('staff.notifications')); ?>" class="ms-2">Lihat detail →</a>
        </div>
    </div>
</div>
<?php endif; ?>


<div class="card mb-4">
    <div class="card-header bg-white">
        <h5 class="mb-0"><i class="bi bi-graph-up"></i> Grafik Pengunjung</h5>
    </div>
    <div class="card-body">
        
        <div class="btn-group mb-3" role="group">
            <input type="radio" class="btn-check" name="chartType" id="lineChartRadio" value="line" checked>
            <label class="btn btn-outline-primary" for="lineChartRadio">
                <i class="bi bi-graph-up"></i> Line Chart
            </label>

            <input type="radio" class="btn-check" name="chartType" id="barChartRadio" value="bar">
            <label class="btn btn-outline-primary" for="barChartRadio">
                <i class="bi bi-bar-chart-fill"></i> Bar Chart
            </label>

            <input type="radio" class="btn-check" name="chartType" id="pieChartRadio" value="pie">
            <label class="btn btn-outline-primary" for="pieChartRadio">
                <i class="bi bi-pie-chart-fill"></i> Pie Chart
            </label>
        </div>

        
        <div id="lineChartContainer" class="chart-container">
            <canvas id="lineChart"></canvas>
        </div>
        <div id="barChartContainer" class="chart-container" style="display: none;">
            <canvas id="barChart"></canvas>
        </div>
        <div id="pieChartContainer" class="chart-container" style="display: none;">
            <canvas id="pieChart"></canvas>
        </div>
    </div>
</div>


<div class="card">
    <div class="card-header bg-white">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="bi bi-table"></i> Daftar Pengunjung</h5>
            <div>
                <a href="<?php echo e(route('staff.export.excel', request()->query())); ?>" class="btn btn-success btn-sm">
                    <i class="bi bi-file-earmark-excel"></i> Export Excel
                </a>
                <a href="<?php echo e(route('staff.export.pdf', request()->query())); ?>" class="btn btn-danger btn-sm">
                    <i class="bi bi-file-earmark-pdf"></i> Export PDF
                </a>
            </div>
        </div>
        <ul class="nav nav-tabs mt-3" id="visitorTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link <?php echo e($type == 'all' ? 'active' : ''); ?>" href="<?php echo e(route('staff.visitors.dashboard', array_merge(request()->query(), ['type' => 'all']))); ?>">
                    Semua
                </a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link <?php echo e($type == 'booking' ? 'active' : ''); ?>" href="<?php echo e(route('staff.visitors.dashboard', array_merge(request()->query(), ['type' => 'booking']))); ?>">
                    Booking
                </a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link <?php echo e($type == 'walkin' ? 'active' : ''); ?>" href="<?php echo e(route('staff.visitors.dashboard', array_merge(request()->query(), ['type' => 'walkin']))); ?>">
                    Walk-in
                </a>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <?php if($visitors->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Foto</th>
                        <th>Nama</th>
                        <th>Tipe</th>
                        <th>Telepon</th>
                        <th>Keperluan</th>
                        <th>Check-in</th>
                        <th>Check-out</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <img src="<?php echo e($visitor->photo_url); ?>" alt="Photo" class="rounded-circle" style="width: 40px; height: 40px; object-fit: cover;">
                        </td>
                        <td><?php echo e($visitor->name); ?></td>
                        <td><span class="badge bg-info">Walk-in</span></td>
                        <td><?php echo e($visitor->phone); ?></td>
                        <td><?php echo e(Str::limit($visitor->purpose, 30)); ?></td>
                        <td><?php echo e($visitor->check_in_time ? $visitor->check_in_time->format('d M Y H:i') : '-'); ?></td>
                        <td><?php echo e($visitor->check_out_time ? $visitor->check_out_time->format('d M Y H:i') : '-'); ?></td>
                        <td>
                            <?php if($visitor->status == 'pending'): ?>
                                <span class="badge bg-warning">Pending</span>
                            <?php elseif($visitor->status == 'active'): ?>
                                <span class="badge bg-success">Aktif</span>
                            <?php elseif($visitor->status == 'completed'): ?>
                                <span class="badge bg-secondary">Selesai</span>
                            <?php elseif($visitor->status == 'rejected'): ?>
                                <span class="badge bg-danger">Ditolak</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('staff.visitor.detail', $visitor->id)); ?>" class="btn btn-sm btn-primary">
                                <i class="bi bi-eye"></i>
                            </a>
                            <?php if($visitor->isActive()): ?>
                            <form action="<?php echo e(route('staff.visitor.checkout', $visitor->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-warning" onclick="return confirm('Check-out visitor ini?')">
                                    <i class="bi bi-box-arrow-right"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($visitors->links()); ?>

        <?php else: ?>
        <p class="text-muted text-center py-4">Tidak ada data pengunjung.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
// Filter handler
document.getElementById('filterSelect').addEventListener('change', function() {
    let customFields = this.value === 'custom';
    document.getElementById('dateFromGroup').style.display = customFields ? 'block' : 'none';
    document.getElementById('dateToGroup').style.display = customFields ? 'block' : 'none';
});

// Chart data from backend
const chartData = <?php echo json_encode($chartData, 15, 512) ?>;

// Line Chart
const lineCtx = document.getElementById('lineChart').getContext('2d');
const lineChart = new Chart(lineCtx, {
    type: 'line',
    data: {
        labels: chartData.labels,
        datasets: [
            {
                label: 'Booking Visitors',
                data: chartData.booking,
                borderColor: '#28a745',
                backgroundColor: 'rgba(40, 167, 69, 0.1)',
                tension: 0.4
            },
            {
                label: 'Walk-in Visitors',
                data: chartData.walkin,
                borderColor: '#17a2b8',
                backgroundColor: 'rgba(23, 162, 184, 0.1)',
                tension: 0.4
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: true,
                position: 'top'
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1
                }
            }
        }
    }
});

// Bar Chart
const barCtx = document.getElementById('barChart').getContext('2d');
const barChart = new Chart(barCtx, {
    type: 'bar',
    data: {
        labels: chartData.labels,
        datasets: [
            {
                label: 'Booking Visitors',
                data: chartData.booking,
                backgroundColor: '#28a745'
            },
            {
                label: 'Walk-in Visitors',
                data: chartData.walkin,
                backgroundColor: '#17a2b8'
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: true,
                position: 'top'
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1
                }
            }
        }
    }
});

// Pie Chart
const pieCtx = document.getElementById('pieChart').getContext('2d');
const bookingTotal = chartData.booking.reduce((a, b) => a + b, 0);
const walkinTotal = chartData.walkin.reduce((a, b) => a + b, 0);

const pieChart = new Chart(pieCtx, {
    type: 'pie',
    data: {
        labels: ['Booking Visitors', 'Walk-in Visitors'],
        datasets: [{
            data: [bookingTotal, walkinTotal],
            backgroundColor: ['#28a745', '#17a2b8']
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: true,
                position: 'top'
            }
        }
    }
});

// Chart type switcher
document.querySelectorAll('input[name="chartType"]').forEach(radio => {
    radio.addEventListener('change', function() {
        document.getElementById('lineChartContainer').style.display = 'none';
        document.getElementById('barChartContainer').style.display = 'none';
        document.getElementById('pieChartContainer').style.display = 'none';
        
        document.getElementById(this.value + 'ChartContainer').style.display = 'block';
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\x1\Desktop\New folder\webuas - fix  V 2\resources\views/staff/dashboard-visitors.blade.php ENDPATH**/ ?>