

<?php $__env->startSection('title', 'User Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">My Dashboard</h2>
    <a href="<?php echo e(route('bookings.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> New Booking
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white py-3">
        <h5 class="mb-0">
            <i class="bi bi-calendar-check text-success"></i> My Active Bookings
        </h5>
    </div>
    <div class="card-body">
        <?php if($activeBookings->count() > 0): ?>
            <div class="row g-3">
                <?php $__currentLoopData = $activeBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="card h-100 border 
                        <?php if($booking->status === 'approved'): ?> border-success
                        <?php elseif($booking->status === 'pending'): ?> border-warning
                        <?php else: ?> border-danger
                        <?php endif; ?>">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <h5 class="card-title mb-0">
                                    <i class="bi bi-building"></i> <?php echo e($booking->lab->name); ?>

                                </h5>
                                <span class="badge 
                                    <?php if($booking->status === 'approved'): ?> bg-success
                                    <?php elseif($booking->status === 'pending'): ?> bg-warning
                                    <?php else: ?> bg-danger
                                    <?php endif; ?>">
                                    <?php echo e(ucfirst($booking->status)); ?>

                                </span>
                            </div>
                            
                            <div class="mb-2">
                                <small class="text-muted">
                                    <i class="bi bi-clock"></i> Start:
                                </small>
                                <div><?php echo e($booking->start_time->format('d M Y, H:i')); ?></div>
                            </div>
                            
                            <div class="mb-2">
                                <small class="text-muted">
                                    <i class="bi bi-clock-fill"></i> End:
                                </small>
                                <div><?php echo e($booking->end_time->format('d M Y, H:i')); ?></div>
                            </div>
                            
                            <div class="mb-3">
                                <small class="text-muted">
                                    <i class="bi bi-file-text"></i> Purpose:
                                </small>
                                <div class="small"><?php echo e($booking->purpose); ?></div>
                            </div>
                            
                            <div class="d-flex gap-2">
                                <a href="<?php echo e(route('bookings.show', $booking)); ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-eye"></i> View Details
                                </a>
                                <?php if($booking->status === 'pending'): ?>
                                <form action="<?php echo e(route('bookings.destroy', $booking)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" 
                                            onclick="return confirm('Are you sure you want to cancel this booking?')">
                                        <i class="bi bi-trash"></i> Cancel
                                    </button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="text-center py-5 text-muted">
                <i class="bi bi-calendar-x" style="font-size: 3rem;"></i>
                <p class="mt-3">You don't have any active bookings</p>
                <a href="<?php echo e(route('bookings.create')); ?>" class="btn btn-primary">
                    <i class="bi bi-plus-circle"></i> Create Your First Booking
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\x1\Desktop\New folder\webuas\resources\views/user/dashboard.blade.php ENDPATH**/ ?>