

<?php $__env->startSection('title', 'Guest Check-in'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="card shadow-lg border-0">
                <div class="card-header bg-gradient text-white text-center py-4" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                    <h3 class="mb-0">
                        <i class="bi bi-person-check-fill"></i> Guest Check-in
                    </h3>
                    <p class="mb-0 mt-2 small">SIM-LAB Visitor Management</p>
                </div>
                <div class="card-body p-4">
                    
                    <?php if(session('success') && session('qr_code')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <div class="text-center">
                                <i class="bi bi-check-circle-fill fs-1"></i>
                                <h5 class="mt-2">Check-in Berhasil!</h5>
                                <p class="mb-2"><?php echo e(session('message')); ?></p>
                                
                                <?php if(session('visitor')): ?>
                                    <div class="badge bg-success mb-2">
                                        <i class="bi bi-person-badge"></i> <?php echo e(session('visitor')->visitor_type === 'mahasiswa' ? 'Mahasiswa' : 'Dosen'); ?>

                                    </div>
                                <?php endif; ?>
                                
                                <div class="my-3">
                                    <p class="small text-muted">QR Code untuk Check-in:</p>
                                    <div class="bg-white p-3 d-inline-block border rounded">
                                        
                                        <div style="width: 200px; height: 200px; background: #f8f9fa; display: flex; align-items: center; justify-content: center; border: 2px solid #dee2e6;">
                                            <div class="text-center">
                                                <i class="bi bi-qr-code" style="font-size: 80px; color: #000;"></i>
                                                <p class="small mt-2 mb-0">Scan untuk masuk</p>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="small text-muted mt-2">Visitor ID: #V-<?php echo e(session('visitor')->id); ?></p>
                                </div>
                                
                                <button type="button" class="btn btn-sm btn-outline-success" onclick="window.print()">
                                    <i class="bi bi-printer"></i> Print QR Code
                                </button>
                            </div>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php elseif(session('success')): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <i class="bi bi-clock-history"></i> <?php echo e(session('message')); ?>

                            <p class="mb-0 mt-2 small">Staff akan segera mereview permintaan Anda.</p>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <i class="bi bi-exclamation-triangle-fill"></i> <strong>Error:</strong>
                            <ul class="mb-0 mt-2">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('visitor.store')); ?>" method="POST" id="checkInForm">
                        <?php echo csrf_field(); ?>

                        
                        <div class="mb-3">
                            <label for="name" class="form-label fw-bold">
                                Nama Lengkap <span class="text-danger">*</span>
                            </label>
                            <input type="text" 
                                   class="form-control form-control-lg" 
                                   id="name" 
                                   name="name" 
                                   value="<?php echo e(old('name')); ?>" 
                                   placeholder="Masukkan nama lengkap" 
                                   required
                                   autocomplete="off">
                        </div>

                        
                        <div class="mb-3">
                            <label for="nim_nidn" class="form-label fw-bold">
                                NIM/NIDN <span class="text-danger">*</span>
                            </label>
                            <input type="text" 
                                   class="form-control form-control-lg" 
                                   id="nim_nidn" 
                                   name="nim_nidn" 
                                   value="<?php echo e(old('nim_nidn')); ?>" 
                                   placeholder="Contoh: 2110010001 atau 0123456789012"
                                   pattern="[0-9]{8,18}"
                                   title="Masukkan 8-18 digit angka"
                                   required
                                   autocomplete="off">
                            <div class="form-text">
                                <i class="bi bi-info-circle"></i> 
                                <strong>Mahasiswa:</strong> NIM 8-12 digit (dimulai angka 2) | 
                                <strong>Dosen:</strong> NIDN 13-18 digit
                            </div>
                            <div id="visitor-type-indicator" class="mt-2"></div>
                        </div>

                        
                        <div class="mb-4">
                            <label for="purpose" class="form-label fw-bold">
                                Keperluan <span class="text-muted small">(Opsional)</span>
                            </label>
                            <select class="form-select" id="purpose" name="purpose">
                                <option value="Kunjungan Lab" selected>Kunjungan Lab</option>
                                <option value="Praktikum">Praktikum</option>
                                <option value="Penelitian">Penelitian</option>
                                <option value="Konsultasi">Konsultasi</option>
                                <option value="Lainnya">Lainnya</option>
                            </select>
                        </div>

                        
                        <div class="d-grid">
                            <button type="submit" class="btn btn-lg text-white" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                                <i class="bi bi-check-circle"></i> Submit Check-in
                            </button>
                        </div>

                        <div class="text-center mt-3">
                            <a href="<?php echo e(route('schedule.index')); ?>" class="text-muted small">
                                <i class="bi bi-arrow-left"></i> Kembali ke Jadwal
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            
            <div class="card mt-3 border-0 bg-light">
                <div class="card-body text-center small">
                    <p class="mb-1"><i class="bi bi-shield-check text-success"></i> <strong>Auto-Approval</strong></p>
                    <p class="mb-0 text-muted">Sivitas akademik internal (NIM/NIDN valid) akan langsung di-approve</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
// Real-time visitor type detection
document.getElementById('nim_nidn').addEventListener('input', function(e) {
    const value = e.target.value;
    const indicator = document.getElementById('visitor-type-indicator');
    
    if (value.length === 0) {
        indicator.innerHTML = '';
        return;
    }
    
    const length = value.length;
    let type = '';
    let badgeClass = '';
    let icon = '';
    let isValid = false;
    
    // Only numbers allowed
    if (!/^[0-9]*$/.test(value)) {
        indicator.innerHTML = '<span class="badge bg-danger"><i class="bi bi-x-circle"></i> Hanya angka yang diperbolehkan</span>';
        return;
    }
    
    // Detect type
    if (length >= 8 && length <= 12) {
        type = 'Mahasiswa (NIM)';
        badgeClass = 'bg-primary';
        icon = 'bi-person';
        
        // Validate: starts with 2
        if (value.startsWith('2')) {
            isValid = true;
            indicator.innerHTML = '<span class="badge ' + badgeClass + '"><i class="bi ' + icon + '"></i> ' + type + ' - Valid ✓</span>';
        } else {
            indicator.innerHTML = '<span class="badge bg-warning text-dark"><i class="bi ' + icon + '"></i> ' + type + ' - NIM harus dimulai angka 2</span>';
        }
    } else if (length >= 13 && length <= 18) {
        type = 'Dosen (NIDN)';
        badgeClass = 'bg-success';
        icon = 'bi-person-badge';
        isValid = true;
        indicator.innerHTML = '<span class="badge ' + badgeClass + '"><i class="bi ' + icon + '"></i> ' + type + ' - Valid ✓</span>';
    } else if (length < 8) {
        indicator.innerHTML = '<span class="badge bg-secondary"><i class="bi bi-three-dots"></i> Ketik ' + (8 - length) + ' digit lagi...</span>';
    } else {
        type = 'Visitor Umum';
        badgeClass = 'bg-info';
        icon = 'bi-person-circle';
        indicator.innerHTML = '<span class="badge ' + badgeClass + '"><i class="bi ' + icon + '"></i> ' + type + ' (Perlu approval staff)</span>';
    }
});

// Form validation feedback
document.getElementById('checkInForm').addEventListener('submit', function(e) {
    const nimNidn = document.getElementById('nim_nidn').value;
    
    if (nimNidn.length < 8) {
        e.preventDefault();
        alert('NIM/NIDN minimal 8 digit!');
        return false;
    }
    
    if (!/^[0-9]+$/.test(nimNidn)) {
        e.preventDefault();
        alert('NIM/NIDN hanya boleh berisi angka!');
        return false;
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\x1\Desktop\New folder\webuas - fix  V 2\resources\views/guest/check-in.blade.php ENDPATH**/ ?>