

<?php $__env->startSection('title', 'Daftar Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">
        <i class="bi bi-calendar-check"></i> Daftar Peminjaman
    </h2>
    <?php if(auth()->user()->isUser()): ?>
    <a href="<?php echo e(route('bookings.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> Tambah Peminjaman
    </a>
    <?php endif; ?>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <?php if($bookings->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <?php if(!auth()->user()->isUser()): ?>
                            <th>Pengguna</th>
                            <?php endif; ?>
                            <th>Lab</th>
                            <th>Waktu Mulai</th>
                            <th>Waktu Selesai</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($booking->id); ?></td>
                            <?php if(!auth()->user()->isUser()): ?>
                            <td>
                                <div><?php echo e($booking->user->name); ?></div>
                                <small class="text-muted"><?php echo e($booking->user->email); ?></small>
                            </td>
                            <?php endif; ?>
                            <td>
                                <i class="bi bi-building"></i> <?php echo e($booking->lab->name); ?>

                            </td>
                            <td><?php echo e($booking->start_time->format('d M Y, H:i')); ?></td>
                            <td><?php echo e($booking->end_time->format('d M Y, H:i')); ?></td>
                            <td>
                                <span class="badge 
                                    <?php if($booking->status === 'approved'): ?> bg-success
                                    <?php elseif($booking->status === 'pending'): ?> bg-warning
                                    <?php else: ?> bg-danger
                                    <?php endif; ?>">
                                    <?php echo e(ucfirst($booking->status)); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('bookings.show', $booking)); ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-eye"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-3">
                <?php echo e($bookings->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-5 text-muted">
                <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                <p class="mt-3">Belum ada peminjaman</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\x1\Desktop\New folder\webuas - fix  V 2\resources\views/bookings/index.blade.php ENDPATH**/ ?>