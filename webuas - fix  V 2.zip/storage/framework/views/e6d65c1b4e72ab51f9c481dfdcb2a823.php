

<?php $__env->startSection('title', 'Laporan Masalah'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">
        <i class="bi bi-tools"></i> Laporan Masalah & Maintenance
    </h2>
    <a href="<?php echo e(route('tickets.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> Laporkan Masalah Baru
    </a>
</div>

<!-- Filter -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('tickets.index')); ?>" class="row g-3">
            <div class="col-md-4">
                <label for="status" class="form-label">Filter berdasarkan Status</label>
                <select class="form-select" id="status" name="status" onchange="this.form.submit()">
                    <option value="">Semua Status</option>
                    <option value="open" <?php echo e(request('status') === 'open' ? 'selected' : ''); ?>>Terbuka</option>
                    <option value="resolved" <?php echo e(request('status') === 'resolved' ? 'selected' : ''); ?>>Selesai</option>
                </select>
            </div>
            
            <div class="col-md-4 d-flex align-items-end">
                <a href="<?php echo e(route('tickets.index')); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-x-circle"></i> Hapus Filter
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Tickets List -->
<div class="row g-3">
    <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div>
                        <h5 class="mb-1">Tiket #<?php echo e($ticket->id); ?></h5>
                        <small class="text-muted">
                            <i class="bi bi-person"></i> <?php echo e($ticket->user->name); ?>

                        </small>
                    </div>
                    <span class="badge <?php echo e($ticket->status === 'open' ? 'bg-warning' : 'bg-success'); ?>" style="font-size: 0.9rem;">
                        <?php echo e($ticket->status === 'open' ? 'Terbuka' : 'Selesai'); ?>

                    </span>
                </div>
                
                <div class="mb-2">
                    <small class="text-muted"><i class="bi bi-laptop"></i> Aset:</small>
                    <div>
                        <code><?php echo e($ticket->asset->code); ?></code> - <?php echo e($ticket->asset->name); ?>

                    </div>
                    <small class="text-muted">
                        <i class="bi bi-building"></i> <?php echo e($ticket->asset->lab->name); ?>

                    </small>
                </div>
                
                <div class="mb-3">
                    <small class="text-muted"><i class="bi bi-file-text"></i> Masalah:</small>
                    <p class="mb-0 small"><?php echo e(Str::limit($ticket->issue_description, 100)); ?></p>
                </div>
                
                <div class="d-flex justify-content-between align-items-center border-top pt-2">
                    <small class="text-muted">
                        <?php echo e($ticket->created_at->diffForHumans()); ?>

                    </small>
                    <div>
                        <a href="<?php echo e(route('tickets.show', $ticket)); ?>" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-eye"></i> Lihat
                        </a>
                        <?php if(auth()->user()->isStaff() && $ticket->status === 'open'): ?>
                        <form action="<?php echo e(route('tickets.updateStatus', $ticket)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="status" value="resolved">
                            <button type="submit" class="btn btn-sm btn-success">
                                <i class="bi bi-check-circle"></i> Selesaikan
                            </button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12">
        <div class="text-center py-5 text-muted">
            <i class="bi bi-inbox" style="font-size: 3rem;"></i>
            <p class="mt-3">Tidak ada laporan masalah ditemukan</p>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php if($tickets->hasPages()): ?>
<div class="mt-4">
    <?php echo e($tickets->appends(request()->query())->links()); ?>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\x1\Desktop\New folder\webuas\resources\views/tickets/index.blade.php ENDPATH**/ ?>