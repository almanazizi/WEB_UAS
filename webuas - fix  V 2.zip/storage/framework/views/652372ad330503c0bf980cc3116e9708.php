
<div class="card border-0 shadow-sm">
    <div class="card-header bg-white py-3">
        <h5 class="mb-0"><i class="bi bi-calendar-week"></i> Tampilan Kalender/Timeline</h5>
    </div>
    <div class="card-body">
        <?php
            $timeSlots = [];
            for ($hour = 8; $hour <= 18; $hour++) {
                $timeSlots[] = sprintf('%02d:00', $hour);
            }
        ?>

        <?php if($bookings->count() > 0): ?>
        <div class="timeline-container">
            <?php $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                // Define this hour slot boundaries
                $slotStart = \Carbon\Carbon::parse($date . ' ' . $slot);
                $slotEnd = $slotStart->copy()->addHour();
                
                // Find all bookings that overlap with this hour slot
                $bookingsInSlot = $bookings->filter(function($booking) use ($slotStart, $slotEnd) {
                    return $booking->start_time < $slotEnd && $booking->end_time > $slotStart;
                });
                
                // Calculate available time segments within this hour
                $segments = [];
                $currentTime = $slotStart->copy();
                
                // Sort bookings by start time
                $sortedBookings = $bookingsInSlot->sortBy('start_time');
                
                foreach ($sortedBookings as $booking) {
                    $bookingStart = max($booking->start_time, $slotStart);
                    $bookingEnd = min($booking->end_time, $slotEnd);
                    
                    // If there's available time before this booking
                    if ($currentTime < $bookingStart) {
                        $segments[] = [
                            'type' => 'available',
                            'start' => $currentTime->format('H:i'),
                            'end' => $bookingStart->format('H:i'),
                        ];
                    }
                    
                    // Add the booking segment
                    $segments[] = [
                        'type' => 'booking',
                        'start' => $bookingStart->format('H:i'),
                        'end' => $bookingEnd->format('H:i'),
                        'booking' => $booking,
                    ];
                    
                    $currentTime = $bookingEnd->copy();
                }
                
                // If there's available time after all bookings
                if ($currentTime < $slotEnd) {
                    $segments[] = [
                        'type' => 'available',
                        'start' => $currentTime->format('H:i'),
                        'end' => $slotEnd->format('H:i'),
                    ];
                }
                
                // If no bookings, entire hour is available
                if ($bookingsInSlot->count() == 0) {
                    $segments[] = [
                        'type' => 'available',
                        'start' => $slotStart->format('H:i'),
                        'end' => $slotEnd->format('H:i'),
                    ];
                }
            ?>
            
            <div class="timeline-slot mb-3 p-3 border rounded">
                <div class="d-flex align-items-start">
                    <div class="time-label fw-bold text-muted me-3" style="min-width: 80px;">
                        <?php echo e($slot); ?> WIB
                    </div>
                    <div class="flex-grow-1">
                        <?php $__currentLoopData = $segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($segment['type'] === 'available'): ?>
                                
                                <div class="available-slot p-2 rounded mb-2 text-center" style="background: #f0f7ff; border: 2px dashed #0d6efd;">
                                    <i class="bi bi-check-circle text-success"></i> 
                                    <strong>Tersedia</strong>
                                    <br>
                                    <small class="text-muted"><?php echo e($segment['start']); ?> - <?php echo e($segment['end']); ?> WIB</small>
                                </div>
                            <?php else: ?>
                                
                                <?php $booking = $segment['booking']; ?>
                                <div class="booking-card card mb-2 booking-block" style="border-left-color: <?php echo e('#' . substr(md5($booking->lab->id), 0, 6)); ?>; border-left-width: 4px;">
                                    <div class="card-body py-2 px-3">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <div class="flex-grow-1">
                                                <h6 class="mb-1">
                                                    <i class="bi bi-building"></i> <?php echo e($booking->lab->name); ?>

                                                </h6>
                                                <p class="mb-1 small">
                                                    <i class="bi bi-clock"></i> 
                                                    <strong class="text-primary"><?php echo e($segment['start']); ?> - <?php echo e($segment['end']); ?> WIB</strong>
                                                    <?php if($segment['start'] != $booking->start_time->format('H:i') || $segment['end'] != $booking->end_time->format('H:i')): ?>
                                                        <br>
                                                        <span class="text-muted small">
                                                            (Total booking: <?php echo e($booking->start_time->format('H:i')); ?> - <?php echo e($booking->end_time->format('H:i')); ?>)
                                                        </span>
                                                    <?php endif; ?>
                                                </p>
                                                <p class="mb-1 small">
                                                    <i class="bi bi-person"></i> <?php echo e($booking->user->name); ?>

                                                </p>
                                                <p class="mb-0 small text-muted">
                                                    <i class="bi bi-file-text"></i> <?php echo e(Str::limit($booking->purpose, 60)); ?>

                                                </p>
                                            </div>
                                            <span class="badge <?php echo e($booking->status === 'approved' ? 'bg-success' : 'bg-warning'); ?>">
                                                <?php echo e($booking->status === 'approved' ? 'Disetujui' : 'Pending'); ?>

                                            </span>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
        <div class="text-center py-5 text-muted">
            <i class="bi bi-calendar-x" style="font-size: 3rem;"></i>
            <p class="mt-3">Tidak ada peminjaman untuk tanggal ini. Semua slot tersedia!</p>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\x1\Desktop\New folder\webuas - fix\resources\views/schedule/partials/calendar_view.blade.php ENDPATH**/ ?>