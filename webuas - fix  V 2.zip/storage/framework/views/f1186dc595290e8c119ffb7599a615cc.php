

<?php $__env->startSection('title', 'Asset Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <a href="<?php echo e(route('assets.index')); ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Back to Assets
    </a>
</div>

<div class="row">
    <div class="col-md-5">
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <h4 class="mb-0">
                        <code><?php echo e($asset->code); ?></code>
                    </h4>
                    <span class="badge <?php echo e($asset->condition === 'good' ? 'bg-success' : 'bg-danger'); ?>" style="font-size: 1rem;">
                        <?php echo e(ucfirst($asset->condition)); ?>

                    </span>
                </div>
                
                <h5 class="mb-3"><?php echo e($asset->name); ?></h5>
                
                <div class="mb-3">
                    <h6 class="text-muted mb-2"><i class="bi bi-building"></i> Laboratory</h6>
                    <p class="mb-0"><?php echo e($asset->lab->name); ?></p>
                    <small class="text-muted"><?php echo e($asset->lab->location); ?></small>
                </div>
                
                <div class="mb-3">
                    <h6 class="text-muted mb-2"><i class="bi bi-card-list"></i> Specification</h6>
                    <p class="mb-0"><?php echo e($asset->spec ?? 'No specification provided'); ?></p>
                </div>
                
                <hr>
                
                <div class="small text-muted">
                    <div class="mb-1">
                        <strong>Created:</strong> <?php echo e($asset->created_at->format('d M Y, H:i')); ?>

                    </div>
                    <div>
                        <strong>Updated:</strong> <?php echo e($asset->updated_at->format('d M Y, H:i')); ?>

                    </div>
                </div>
                
                <?php if(auth()->user()->isStaff()): ?>
                <hr>
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('assets.edit', $asset)); ?>" class="btn btn-primary">
                        <i class="bi bi-pencil"></i> Edit Asset
                    </a>
                    <form action="<?php echo e(route('assets.destroy', $asset)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger w-100" 
                                onclick="return confirm('Are you sure you want to delete this asset?')">
                            <i class="bi bi-trash"></i> Delete Asset
                        </button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-7">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0">
                    <i class="bi bi-tools"></i> Maintenance Tickets
                </h5>
            </div>
            <div class="card-body">
                <?php if($asset->tickets->count() > 0): ?>
                    <?php $__currentLoopData = $asset->tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-3 border">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <h6 class="mb-1">Ticket #<?php echo e($ticket->id); ?></h6>
                                    <small class="text-muted">
                                        <i class="bi bi-person"></i> <?php echo e($ticket->user->name); ?>

                                    </small>
                                </div>
                                <span class="badge <?php echo e($ticket->status === 'open' ? 'bg-warning' : 'bg-success'); ?>">
                                    <?php echo e(ucfirst($ticket->status)); ?>

                                </span>
                            </div>
                            
                            <p class="mb-2 small"><?php echo e($ticket->issue_description); ?></p>
                            
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">
                                    <?php echo e($ticket->created_at->diffForHumans()); ?>

                                </small>
                                <a href="<?php echo e(route('tickets.show', $ticket)); ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-eye"></i> View
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="text-center py-5 text-muted">
                        <i class="bi bi-inbox" style="font-size: 2rem;"></i>
                        <p class="mt-2">No maintenance tickets for this asset</p>
                        <a href="<?php echo e(route('tickets.create')); ?>" class="btn btn-sm btn-primary">
                            <i class="bi bi-plus-circle"></i> Report Issue
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\x1\Desktop\New folder\webuas\resources\views/assets/show.blade.php ENDPATH**/ ?>