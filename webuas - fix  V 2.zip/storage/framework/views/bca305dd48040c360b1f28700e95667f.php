
<div class="card border-0 shadow-sm">
    <div class="card-header bg-white py-3">
        <h5 class="mb-0"><i class="bi bi-building"></i> Tampilan Per Laboratorium</h5>
    </div>
    <div class="card-body">
        <?php
            // Group bookings by lab
            $bookingsByLab = $bookings->groupBy('lab_id');
        ?>

        <?php if($labs->count() > 0): ?>
        <div class="accordion" id="labAccordion">
            <?php $__currentLoopData = $labs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $labBookings = $bookingsByLab->get($lab->id, collect());
                $labColor = '#' . substr(md5($lab->id), 0, 6);
            ?>
            
            <div class="accordion-item mb-3 border-0 shadow-sm">
                <h2 class="accordion-header">
                    <button class="accordion-button <?php echo e($index === 0 ? '' : 'collapsed'); ?>" 
                            type="button" 
                            data-bs-toggle="collapse" 
                            data-bs-target="#lab<?php echo e($lab->id); ?>"
                            style="border-left: 5px solid <?php echo e($labColor); ?>;">
                        <div class="w-100 d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?php echo e($lab->name); ?></strong>
                                <br>
                                <small class="text-muted"><?php echo e($lab->location); ?> • Kapasitas: <?php echo e($lab->capacity); ?> orang</small>
                            </div>
                            <span class="badge bg-primary">
                                <?php echo e($labBookings->count()); ?> peminjaman
                            </span>
                        </div>
                    </button>
                </h2>
                <div id="lab<?php echo e($lab->id); ?>" 
                     class="accordion-collapse collapse <?php echo e($index === 0 ? 'show' : ''); ?>" 
                     data-bs-parent="#labAccordion">
                    <div class="accordion-body">
                        <?php if($labBookings->count() > 0): ?>
                        <div class="timeline">
                            <?php $__currentLoopData = $labBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="booking-card card mb-2 booking-block" style="border-left-color: <?php echo e($labColor); ?>; border-left-width: 4px;">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col-md-3">
                                            <i class="bi bi-clock"></i> 
                                            <strong><?php echo e($booking->start_time->format('H:i')); ?> - <?php echo e($booking->end_time->format('H:i')); ?></strong>
                                            <br>
                                            <small class="text-muted"><?php echo e($booking->start_time->format('d M Y')); ?></small>
                                        </div>
                                        <div class="col-md-3">
                                            <i class="bi bi-person"></i> <?php echo e($booking->user->name); ?>

                                        </div>
                                        <div class="col-md-5">
                                            <i class="bi bi-file-text"></i> <?php echo e($booking->purpose); ?>

                                        </div>
                                        <div class="col-md-1 text-end">
                                            <span class="badge <?php echo e($booking->status === 'approved' ? 'bg-success' : 'bg-warning'); ?>">
                                                <i class="bi <?php echo e($booking->status === 'approved' ? 'bi-check-circle' : 'bi-clock'); ?>"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        
                        <div class="alert alert-info mt-3 mb-0">
                            <i class="bi bi-info-circle"></i> 
                            <strong>Slot Tersedia:</strong> 
                            Lab ini masih bisa dipinjam di luar waktu yang telah terisi di atas 
                            (jam operasional: 08:00 - 18:00 WIB)
                        </div>
                        <?php else: ?>
                        <div class="text-center py-4 text-muted">
                            <i class="bi bi-check-circle-fill text-success" style="font-size: 3rem;"></i>
                            <p class="mt-2 mb-0">Lab ini sepenuhnya tersedia untuk tanggal yang dipilih!</p>
                            <small class="text-muted">Jam operasional: 08:00 - 18:00 WIB</small>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
        <div class="text-center py-5 text-muted">
            <i class="bi bi-building-x" style="font-size: 3rem;"></i>
            <p class="mt-3">Tidak ada laboratorium yang tersedia.</p>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\x1\Desktop\New folder\webuas - fix\resources\views/schedule/partials/lab_view.blade.php ENDPATH**/ ?>