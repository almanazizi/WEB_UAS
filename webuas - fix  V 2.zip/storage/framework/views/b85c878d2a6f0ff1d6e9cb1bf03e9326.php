

<?php $__env->startSection('title', 'Detail Pengunjung'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <a href="<?php echo e(route('staff.visitors.dashboard')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Kembali
    </a>
</div>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="card shadow-lg border-0">
            <div class="card-header bg-gradient text-white py-3" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                <h4 class="mb-0">
                    <i class="bi bi-person-badge"></i> Detail Pengunjung
                </h4>
            </div>
            <div class="card-body p-4">
                
                <div class="text-center mb-4">
                    <img src="<?php echo e($visitor->photo_url); ?>" alt="<?php echo e($visitor->name); ?>" 
                         class="img-thumbnail rounded-circle shadow" 
                         style="width: 200px; height: 200px; object-fit: cover;">
                </div>

                
                <table class="table table-borderless">
                    <tr>
                        <th style="width: 200px;">Status:</th>
                        <td>
                            <?php if($visitor->status == 'pending'): ?>
                                <span class="badge bg-warning fs-6">⏳ Menunggu Approval</span>
                            <?php elseif($visitor->status == 'approved'): ?>
                                <span class="badge bg-info fs-6">✓ Disetujui</span>
                            <?php elseif($visitor->status == 'active'): ?>
                                <span class="badge bg-success fs-6">✓ Sedang Aktif</span>
                            <?php elseif($visitor->status == 'completed'): ?>
                                <span class="badge bg-secondary fs-6">✓ Selesai</span>
                            <?php elseif($visitor->status == 'rejected'): ?>
                                <span class="badge bg-danger fs-6">✗ Ditolak</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Nama Lengkap:</th>
                        <td><strong><?php echo e($visitor->name); ?></strong></td>
                    </tr>
                    <tr>
                        <th>Email:</th>
                        <td><?php echo e($visitor->email ?? '-'); ?></td>
                    </tr>
                    <tr>
                        <th>No. Telepon:</th>
                        <td><?php echo e($visitor->phone); ?></td>
                    </tr>
                    <tr>
                        <th>Keperluan:</th>
                        <td><?php echo e($visitor->purpose); ?></td>
                    </tr>
                    <tr>
                        <th>Staff/Departemen Dituju:</th>
                        <td><?php echo e($visitor->person_to_meet); ?></td>
                    </tr>
                    <tr>
                        <th>Waktu Pendaftaran:</th>
                        <td><?php echo e($visitor->created_at->format('d M Y, H:i')); ?> WIB</td>
                    </tr>
                    <?php if($visitor->check_in_time): ?>
                    <tr>
                        <th>Waktu Check-in:</th>
                        <td><?php echo e($visitor->check_in_time->format('d M Y, H:i')); ?> WIB</td>
                    </tr>
                    <?php endif; ?>
                    <?php if($visitor->check_out_time): ?>
                    <tr>
                        <th>Waktu Check-out:</th>
                        <td><?php echo e($visitor->check_out_time->format('d M Y, H:i')); ?> WIB</td>
                    </tr>
                    <?php endif; ?>
                    <?php if($visitor->approver): ?>
                    <tr>
                        <th>Diproses oleh:</th>
                        <td>
                            <?php echo e($visitor->approver->name); ?>

                            <br>
                            <small class="text-muted"><?php echo e($visitor->approved_at->format('d M Y, H:i')); ?> WIB</small>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php if($visitor->notes): ?>
                    <tr>
                        <th>Catatan:</th>
                        <td>
                            <div class="alert alert-warning mb-0">
                                <?php echo e($visitor->notes); ?>

                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </table>

                <hr>

                
                <?php if($visitor->isPending()): ?>
                <div class="row g-3">
                    <div class="col-md-6">
                        <form action="<?php echo e(route('staff.visitor.approve', $visitor->id)); ?>" method="POST" onsubmit="return confirm('Approve pengunjung ini?')">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success w-100 btn-lg">
                                <i class="bi bi-check-circle"></i> Approve
                            </button>
                        </form>
                    </div>
                    <div class="col-md-6">
                        <button type="button" class="btn btn-danger w-100 btn-lg" data-bs-toggle="modal" data-bs-target="#rejectModal">
                            <i class="bi bi-x-circle"></i> Reject
                        </button>
                    </div>
                </div>
                <?php elseif($visitor->isActive()): ?>
                <form action="<?php echo e(route('staff.visitor.checkout', $visitor->id)); ?>" method="POST" onsubmit="return confirm('Check-out pengunjung ini?')">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-warning w-100 btn-lg">
                        <i class="bi bi-box-arrow-right"></i> Check-out Sekarang
                    </button>
                </form>
                <?php elseif($visitor->isCompleted()): ?>
                <div class="alert alert-success text-center">
                    <i class="bi bi-check-circle-fill"></i> Kunjungan telah selesai
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(route('staff.visitor.reject', $visitor->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Reject Pengunjung</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Apakah Anda yakin ingin menolak pengunjung ini?</p>
                    <div class="mb-3">
                        <label for="notes" class="form-label">Alasan Penolakan (Opsional)</label>
                        <textarea class="form-control" id="notes" name="notes" rows="3" placeholder="Masukkan alasan penolakan..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-danger">Ya, Reject</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\x1\Desktop\New folder\webuas - fix  V 2\resources\views/staff/visitor-detail.blade.php ENDPATH**/ ?>