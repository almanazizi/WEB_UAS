

<?php $__env->startSection('title', 'Notifikasi Pengunjung'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h2><i class="bi bi-bell-fill"></i> Notifikasi Pengunjung</h2>
    <p class="text-muted">Pengunjung yang menunggu approval</p>
</div>

<?php if($pendingVisitors->count() > 0): ?>
<div class="row">
    <?php $__currentLoopData = $pendingVisitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-6 mb-4">
        <div class="card shadow-sm border-warning border-2">
            <div class="card-body">
                <div class="d-flex align-items-start">
                    <img src="<?php echo e($visitor->photo_url); ?>" alt="<?php echo e($visitor->name); ?>" 
                         class="rounded-circle me-3" 
                         style="width: 80px; height: 80px; object-fit: cover;">
                    <div class="flex-grow-1">
                        <h5 class="card-title mb-1"><?php echo e($visitor->name); ?></h5>
                        <p class="text-muted small mb-2">
                            <i class="bi bi-clock"></i> <?php echo e($visitor->created_at->diffForHumans()); ?>

                        </p>
                        <p class="mb-2">
                            <i class="bi bi-telephone"></i> <?php echo e($visitor->phone); ?><br>
                            <i class="bi bi-bullseye"></i> <?php echo e(Str::limit($visitor->purpose, 50)); ?><br>
                            <i class="bi bi-person"></i> Ingin bertemu: <?php echo e($visitor->person_to_meet); ?>

                        </p>
                        <span class="badge bg-warning">
                            <i class="bi bi-hourglass-split"></i> Menunggu Approval
                        </span>
                    </div>
                </div>
                <hr>
                <div class="row g-2">
                    <div class="col-6">
                        <form action="<?php echo e(route('staff.visitor.approve', $visitor->id)); ?>" method="POST" onsubmit="return confirm('Approve visitor ini?')">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success w-100">
                                <i class="bi bi-check-circle"></i> Approve
                            </button>
                        </form>
                    </div>
                    <div class="col-6">
                        <a href="<?php echo e(route('staff.visitor.detail', $visitor->id)); ?>" class="btn btn-outline-primary w-100">
                            <i class="bi bi-eye"></i> Detail
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php else: ?>
<div class="alert alert-info">
    <i class="bi bi-info-circle"></i> Tidak ada pengunjung yang menunggu approval.
</div>
<?php endif; ?>

<div class="mt-4">
    <a href="<?php echo e(route('staff.visitors.dashboard')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Kembali ke Dashboard
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\x1\Desktop\New folder\webuas - fix  V 2\resources\views/staff/notifications.blade.php ENDPATH**/ ?>