

<?php $__env->startSection('title', 'Beranda Staff'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h2 class="fw-bold">
        <i class="bi bi-speedometer2"></i> Beranda

 Staff/PJ Lab
    </h2>
    <p class="text-muted">Kelola peminjaman laboratorium dan maintenance</p>
</div>

<!-- Pending Bookings Table -->
<div class="card border-0 shadow-sm">
    <div class="card-header bg-white py-3">
        <h5 class="mb-0">
            <i class="bi bi-clock-history text-warning"></i> Peminjaman Menunggu Persetujuan
        </h5>
    </div>
    <div class="card-body">
        <?php if($pendingBookings->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Peminjam</th>
                            <th>Lab</th>
                            <th>Waktu</th>
                            <th>Tujuan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pendingBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div>
                                    <strong><?php echo e($booking->user->name); ?></strong>
                                    <br>
                                    <small class="text-muted"><?php echo e($booking->user->email); ?></small>
                                </div>
                            </td>
                            <td>
                                <i class="bi bi-building"></i> <?php echo e($booking->lab->name); ?>

                            </td>
                            <td>
                                <div>
                                    <small class="text-muted">
                                        <i class="bi bi-calendar"></i> <?php echo e($booking->start_time->format('d M Y')); ?>

                                    </small>
                                    <br>
                                    <i class="bi bi-clock"></i> 
                                    <?php echo e($booking->start_time->format('H:i')); ?> - <?php echo e($booking->end_time->format('H:i')); ?>

                                </div>
                            </td>
                            <td>
                                <small><?php echo e(Str::limit($booking->purpose, 50)); ?></small>
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('bookings.show', $booking)); ?>" 
                                       class="btn btn-outline-info" title="Lihat Detail">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <form action="<?php echo e(route('bookings.updateStatus', $booking)); ?>" 
                                          method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="approved">
                                        <button type="submit" class="btn btn-success" title="Setujui">
                                            <i class="bi bi-check-circle"></i>
                                        </button>
                                    </form>
                                    <form action="<?php echo e(route('bookings.updateStatus', $booking)); ?>" 
                                          method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="rejected">
                                        <button type="submit" class="btn btn-danger" title="Tolak">
                                            <i class="bi bi-x-circle"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-5 text-muted">
                <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                <p class="mt-3">Tidak ada peminjaman yang menunggu persetujuan</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Quick Links -->
<div class="row mt-4 g-3">
    <div class="col-md-3">
        <a href="<?php echo e(route('labs.index')); ?>" class="btn btn-outline-primary w-100">
            <i class="bi bi-building"></i> Kelola Laboratorium
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo e(route('assets.index')); ?>" class="btn btn-outline-success w-100">
            <i class="bi bi-laptop"></i> Kelola Inventaris
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo e(route('bookings.index')); ?>" class="btn btn-outline-info w-100">
            <i class="bi bi-calendar-check"></i> Semua Peminjaman
        </a>
    </div>
    <div class="col-md-3">
        <a href="<?php echo e(route('tickets.index')); ?>" class="btn btn-outline-warning w-100">
            <i class="bi bi-tools"></i> Laporan Masalah
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\x1\Desktop\New folder\webuas - fix\resources\views/staff/dashboard.blade.php ENDPATH**/ ?>