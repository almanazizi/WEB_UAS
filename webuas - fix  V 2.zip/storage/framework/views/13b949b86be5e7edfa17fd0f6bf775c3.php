

<?php $__env->startSection('title', 'Inventaris'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">
        <i class="bi bi-laptop"></i> Inventaris Aset
    </h2>
    <?php if(auth()->user()->isStaff()): ?>
    <a href="<?php echo e(route('assets.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> Tambah Aset Baru
    </a>
    <?php endif; ?>
</div>

<!-- Filters -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('assets.index')); ?>" class="row g-3">
            <div class="col-md-4">
                <label for="lab_id" class="form-label">Filter berdasarkan Lab</label>
                <select class="form-select" id="lab_id" name="lab_id" onchange="this.form.submit()">
                    <option value="">Semua Laboratorium</option>
                    <?php $__currentLoopData = $labs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($lab->id); ?>" <?php echo e(request('lab_id') == $lab->id ? 'selected' : ''); ?>>
                            <?php echo e($lab->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            
            <div class="col-md-4">
                <label for="condition" class="form-label">Filter berdasarkan Kondisi</label>
                <select class="form-select" id="condition" name="condition" onchange="this.form.submit()">
                    <option value="">Semua Kondisi</option>
                    <option value="good" <?php echo e(request('condition') === 'good' ? 'selected' : ''); ?>>Baik</option>
                    <option value="bad" <?php echo e(request('condition') === 'bad' ? 'selected' : ''); ?>>Rusak</option>
                </select>
            </div>
            
            <div class="col-md-4 d-flex align-items-end">
                <a href="<?php echo e(route('assets.index')); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-x-circle"></i> Hapus Filter
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Assets Table -->
<div class="card border-0 shadow-sm">
    <div class="card-body">
        <?php if($assets->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama</th>
                            <th>Lab</th>
                            <th>Spesifikasi</th>
                            <th>Kondisi</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><code><?php echo e($asset->code); ?></code></td>
                            <td><?php echo e($asset->name); ?></td>
                            <td>
                                <i class="bi bi-building"></i> <?php echo e($asset->lab->name); ?>

                            </td>
                            <td><small><?php echo e(Str::limit($asset->spec, 50)); ?></small></td>
                            <td>
                                <span class="badge <?php echo e($asset->condition === 'good' ? 'bg-success' : 'bg-danger'); ?>">
                                    <?php echo e($asset->condition === 'good' ? 'Baik' : 'Rusak'); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('assets.show', $asset)); ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <?php if(auth()->user()->isStaff()): ?>
                                <a href="<?php echo e(route('assets.edit', $asset)); ?>" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-3">
                <?php echo e($assets->appends(request()->query())->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-5 text-muted">
                <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                <p class="mt-3">Tidak ada aset ditemukan</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\x1\Desktop\New folder\webuas - fix\resources\views/assets/index.blade.php ENDPATH**/ ?>